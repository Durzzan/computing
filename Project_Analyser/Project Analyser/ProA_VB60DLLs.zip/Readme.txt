ProA_VB60DLLs.zip
Library files for Project Analyzer v10 (compatible with v5-v10)

This package includes the run-time files required by Project Analyzer.


Who should install this package
===============================
* Install these run-times to use Project Analyzer on a computer without
  a Visual Basic 6.0 installation. After installing run project.exe.
* If you have Visual Basic 6.0, you don't need to run this setup. 
  Just run project.exe.


How to install libraries
========================
 1. Unzip this library package to a temporary directory.
 2. Run setup.exe.
[3. If installation requires reboot, continue by running continue.exe.]
 4. After installation, unpack the Project Analyzer .zip file.
 5. Start Project Analyzer by running project.exe .


Installed files
===============
Filename,date,size,version
VB6STKIT.DLL, 6/18/98 12:00:00 AM, 102912,6.0.81.69
COMCAT.DLL,   5/31/98 12:00:00 AM,  22288,4.71.1460.1
Stdole2.tlb,  6/02/98  3:46:22 PM,  17920,2.30.4261.1
ASYCFILT.DLL, 6/02/98  6:24:06 PM, 147728,2.30.4261.1
Olepro32.dll, 6/02/98  6:24:08 PM, 164112,5.0.4261.1
OLEAUT32.DLL, 6/02/98  6:24:04 PM, 598288,2.30.4261.1
MSVBVM60.DLL, 6/25/98 12:00:00 AM,1409024,6.0.81.76
MSCOMCTL.OCX, 6/26/98 12:00:00 AM,1062704,6.0.81.77
Comdlg32.ocx, 6/24/98 12:00:00 AM, 140096,6.0.81.69
TLBInf32.dll, 6/18/98  0:00:00 AM, 153600,1.10.8169

These are standard run-time files that originally distributed with
Visual Basic 6.0. If you have Visual Basic 6.0 installed, you have these
files already. Newer file versions are compatible with Project Analyzer.


Aivosto Oy
www.aivosto.com

